import streamlit as st
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC

@st.cache(allow_output_mutation=True)
def load_data():
    return pd.read_csv("../data/heart.csv")

@st.cache(allow_output_mutation=True)
def load_models():
    df = load_data()
    X = df.drop(columns=["target"])
    y = df["target"]
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000).fit(X, y),
        "Random Forest": RandomForestClassifier().fit(X, y),
        "SVM": SVC(probability=True).fit(X, y)
    }
    return models

def main():
    st.title("Heart Disease Prediction")

    st.sidebar.header("Input Medical Data")
    df = load_data()
    X = df.drop(columns=["target"])
    user_input = {}
    for col in X.columns:
        min_val, max_val = int(X[col].min()), int(X[col].max())
        user_input[col] = st.sidebar.slider(col, min_val, max_val, int(df[col].median()))
    input_df = pd.DataFrame([user_input])

    models = load_models()
    model_choice = st.sidebar.selectbox("Choose model", list(models.keys()))
    model = models[model_choice]

    prediction = model.predict(input_df)[0]
    proba = model.predict_proba(input_df)[0][1] if hasattr(model, "predict_proba") else model.decision_function(input_df)[0]

    st.write(f"**Model:** {model_choice}")
    st.write(f"**Prediction (1 = heart disease):** {prediction}")
    st.write(f"**Probability / Score:** {proba:.2f}")

if __name__ == "__main__":
    main()
