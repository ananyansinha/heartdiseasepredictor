# Heart Disease Predictor

This project predicts the likelihood of heart disease using machine learning models developed in Python.

## Project Overview

- Dataset sourced from publicly available heart disease records
- Exploratory Data Analysis and preprocessing
- Model training: Logistic Regression, Random Forest, SVM
- Evaluation through accuracy scores and confusion matrices
- Optional deployment via a Streamlit web app

## File Structure

```
heartdiseasepredictor/
├── data/
│   └── heart.csv
├── notebook/
│   └── heart_prediction.ipynb
├── app/
│   └── app.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Getting Started

### Clone the repository

```bash
git clone https://github.com/ananyansinha/heartdiseasepredictor.git
cd heartdiseasepredictor
```

### Install dependencies

```bash
pip install -r requirements.txt
```

### Run the analysis notebook

```bash
jupyter notebook notebook/heart_prediction.ipynb
```

### (Optional) Run the Streamlit app

```bash
streamlit run app/app.py
```

## Model Performance

| Model                | Accuracy |
|---------------------|----------|
| Logistic Regression | ~85%     |
| Random Forest       | ~87%     |
| Support Vector Machine | ~86%  |

Detailed evaluation (confusion matrices, precision, recall) is available in the notebook.

## Technologies Used

- Python (Pandas, NumPy)
- Scikit-learn
- Seaborn, Matplotlib
- Jupyter Notebook
- Streamlit (optional)

## Author

Ananya Sinha  
GitHub: [ananyansinha](https://github.com/ananyansinha)

## License

Licensed under the MIT License.
